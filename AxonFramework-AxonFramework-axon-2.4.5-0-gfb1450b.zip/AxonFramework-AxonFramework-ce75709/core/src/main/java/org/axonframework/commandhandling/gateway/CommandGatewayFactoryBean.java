/*
 * Copyright (c) 2010-2014. Axon Framework
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.axonframework.commandhandling.gateway;

import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.CommandCallback;
import org.axonframework.commandhandling.CommandDispatchInterceptor;
import org.axonframework.common.Assert;
import org.axonframework.common.AxonConfigurationException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.FactoryBeanNotInitializedException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Required;

import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;

/**
 * FactoryBean that creates a gateway instance for any given (compatible) interface. If no explicit interface is
 * provided, the {@link CommandGateway} interface is assumed.
 * <p/>
 * For details about the structure of compatible interfaces, see {@link GatewayProxyFactory}.
 *
 * @param <T> The type of gateway to be created by this factory bean. Note that the correct interface must also be set
 *            using {@link #setGatewayInterface(Class)}. Failure to do so may result in class cast exceptions.
 * @author Allard Buijze
 * @see GatewayProxyFactory
 * @since 2.0
 */
public class CommandGatewayFactoryBean<T> implements FactoryBean<T>, InitializingBean {

    private CommandBus commandBus;
    private RetryScheduler retryScheduler;
    private List<CommandDispatchInterceptor> dispatchInterceptors = Collections.emptyList();
    private List<CommandCallback<?>> commandCallbacks = Collections.emptyList();
    private T gateway;
    private Class<T> gatewayInterface;

    @Override
    public T getObject() throws Exception {
        if (gateway == null) {
            throw new FactoryBeanNotInitializedException();
        }
        return gateway;
    }

    @Override
    public Class<?> getObjectType() {
        return gatewayInterface;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void afterPropertiesSet() throws Exception {
        if (commandBus == null) {
            throw new AxonConfigurationException("CommandBus may not be null");
        }
        if (gatewayInterface == null) {
            gatewayInterface = (Class<T>) CommandGateway.class;
        }
        final GatewayProxyFactory factory = new GatewayProxyFactory(commandBus, retryScheduler, dispatchInterceptors);
        for (CommandCallback<?> commandCallback : commandCallbacks) {
            factory.registerCommandCallback(commandCallback);
        }
        gateway = factory.createGateway(gatewayInterface);
    }

    /**
     * Sets the command bus on which the Gateway must dispatch commands. This property is required.
     *
     * @param commandBus the command bus on which the Gateway must dispatch commands
     */
    @Required
    public void setCommandBus(CommandBus commandBus) {
        this.commandBus = commandBus;
    }

    /**
     * Sets the RetryScheduler that will be invoked when a command fails execution. If no scheduler is provided,
     * commands will report the failure immediately.
     *
     * @param retryScheduler the RetryScheduler that will be invoked when a command fails execution
     */
    public void setRetryScheduler(RetryScheduler retryScheduler) {
        this.retryScheduler = retryScheduler;
    }

    /**
     * Sets the interface that describes the gateway instance to describe. If no interface is provided, it defaults to
     * {@link CommandGateway}.
     *
     * @param gatewayInterface The interface describing the gateway
     * @throws IllegalArgumentException if the given <code>gatewayInterface</code> is <code>null</code> or not an
     * interface.
     */
    public void setGatewayInterface(Class<T> gatewayInterface) {
        Assert.notNull(gatewayInterface, "The given gateway interface may not be null");
        Assert.isTrue(gatewayInterface.isInterface(), "The given gateway interface must be an interface");
        this.gatewayInterface = gatewayInterface;
    }

    /**
     * Sets the interceptors that should be invoked before a command is dispatched the the Command Bus.
     * <p/>
     * Note that these interceptors will be specific to this Gateway instance. Messages dispatched through other
     * gateways or directly to the command bus will not pass through these interceptors.
     *
     * @param commandDispatchInterceptors the interceptors that should be invoked before a command is dispatched the
     *                                    the
     *                                    Command Bus
     */
    public void setCommandDispatchInterceptors(CommandDispatchInterceptor... commandDispatchInterceptors) {
        setCommandDispatchInterceptors(asList(commandDispatchInterceptors));
    }

    /**
     * Sets the interceptors that should be invoked before a command is dispatched the the Command Bus.
     * <p/>
     * Note that these interceptors will be specific to this Gateway instance. Messages dispatched through other
     * gateways or directly to the command bus will not pass through these interceptors.
     *
     * @param commandDispatchInterceptors the interceptors that should be invoked before a command is dispatched the
     *                                    the
     *                                    Command Bus
     */
    public void setCommandDispatchInterceptors(List<CommandDispatchInterceptor> commandDispatchInterceptors) {
        this.dispatchInterceptors = commandDispatchInterceptors;
    }

    /**
     * Registers the <code>commandCallbacks</code>, which are invoked for each sent command, unless Axon is able to detect
     * that the result of the command does not match the type accepted by that callback.
     * <p/>
     * Axon will check the signature of the onSuccess() method and only invoke the callback if the actual result of the
     * command is an instance of that type. If Axon is unable to detect the type, the callback is always invoked,
     * potentially causing {@link java.lang.ClassCastException}.
     *
     * @param commandCallbacks The callbacks to register
     */
    public void setCommandCallbacks(List<CommandCallback<?>> commandCallbacks) {
        this.commandCallbacks = commandCallbacks;
    }
}
